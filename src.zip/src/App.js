import react,{Component} from 'react';
import Heading from './Components/tittle'
import Gallery from './Components/Gallery'
import AddPhotos from './Components/AddPhoto'
import {connect} from 'react-redux'
import * as Actions from './redux/Photos/phot0Actions'
import {bindActionCreators} from 'redux'

class App extends Component{
    constructor(){
        super()
    }

    componentDidMount(){
        this.props.removephoto()
    }

    render(){
        return(<div>
                <Heading/>
                <AddPhotos {...this.props} />
                <Gallery {...this.props} />
            </div>
        );    
    }
}
const mapStateToProps=(state)=>{
    return{
        posts:state.posts
    }
}

const mapDispatchToProps=(dispatch)=>{
    return bindActionCreators(Actions,dispatch)
}

export default connect(mapStateToProps,mapDispatchToProps)(App);