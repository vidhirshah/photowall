import react from 'react';
import Photo from './Photo'
// import {removephoto} from '../redux/Photos/phot0Actions'
// import {connect} from 'react-redux'
const Gallery=(props)=>{
    return (
        <div className="grid">
            {props.posts.map((value,key)=><Photo post={value} id={key} {...props} />)}
        </div>
    );
}
// const mapStateToProps=(state)=>{
//     return{
//         posts:state.posts
//     }
// }

// const mapDispatchToProps=(dispatch)=>{
//     return{
//         removephoto:()=>dispatch(removephoto())
//     }
// }


// export default connect(mapStateToProps,mapDispatchToProps)(Gallery)
export default Gallery;