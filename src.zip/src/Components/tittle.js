import react from 'react';
const Heading =()=>{
    return(
        <h1>Photowall</h1>
    );
}
export default Heading;