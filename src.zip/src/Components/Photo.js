import react from 'react';
const Photo=(props)=>{
    return <figure className="figure">
        <img className="photo" src={props.post.imageLink} alt={props.post.description} />
        <figurecaption>
            {/* {console.log(props.post)} */}
            <p>{props.post.description}</p>
        </figurecaption>
        <div className="btn">
         <button onClick={()=>{
             props.removephoto(props.id)
         }}>Remove</button>
        </div>
    </figure>
}
export default Photo;