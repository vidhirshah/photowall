import {REMOVE_PHOTO,ADD_PHOTO} from './phototypes'

const initialstate ={
    posts:[{
        id: "0",
        description: "beautiful landscape",
        imageLink: "https://fm.cnbc.com/applications/cnbc.com/resources/img/editorial/2017/08/24/104670887-VacationExplainsTHUMBWEB.1910x1000.jpg"
        }, {
        id: "1",
        description: "Aliens???",
        imageLink: "https://s3.india.com/wp-content/uploads/2017/12/rocket.jpg"
        }, {
        id: "2",
        description: "On a vacation!",
        imageLink: "https://fm.cnbc.com/applications/cnbc.com/resources/img/editorial/2017/08/24/104670887-VacationExplainsTHUMBWEB.1910x1000.jpg"
    }]
}

const photoreducer=(state=initialstate,action)=>{
    switch(action.type){
        case REMOVE_PHOTO:
            return{
            ...state,
            posts:state.posts.filter((value,key)=>{
                return key!=action.index
            })
        }
        case ADD_PHOTO:console.log(action.post)
            return [...state,action.post]
            // return {

               // posts:[...state,action.post]
            // }
        default :return state
    }
}
export default photoreducer