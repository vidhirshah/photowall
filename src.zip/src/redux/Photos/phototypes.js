export const REMOVE_PHOTO="REMOVE_PHOTO"
export const ADD_PHOTO="ADD_PHOTO"