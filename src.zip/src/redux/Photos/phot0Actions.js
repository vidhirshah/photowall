import {REMOVE_PHOTO,ADD_PHOTO} from './phototypes'

export const removephoto =(index)=>{
    return{
        type:REMOVE_PHOTO,
        index:index
    }
}

export const addPhoto =(post)=>{
    return{
        type:ADD_PHOTO,
        post:post
    }
}