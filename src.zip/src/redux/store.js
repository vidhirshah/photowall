import {createStore} from 'redux'
import photoreducer from './Photos/photoreducer'
const store = createStore(photoreducer)
export default store